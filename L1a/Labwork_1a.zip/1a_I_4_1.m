% (c)2021 Hien PHAN.
%Write brief scripts to evaluate the following functions. 
% m = n + 1 with n >1
% m = n - 1 with n <1
clc;
clear;

n = 5
%n = -5

if n>1
    m = n+1
else
    m = n-1
end