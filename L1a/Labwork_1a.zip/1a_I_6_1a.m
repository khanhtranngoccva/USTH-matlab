% (c)2021 Hien PHAN.
% While loop
clc;
clear;

n = 0;
while n<10
    n += 1;
    disp(n);
end