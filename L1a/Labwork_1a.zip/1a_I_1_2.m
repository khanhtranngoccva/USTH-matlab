% (c)2021 Hien PHAN.
clc;
clear;

% Column vector x
x_row=[1 2 3 4 5]
x = [1;2;3;4;5]
%fprintf	('Column vector x = \n');
%disp(x);

% Transpose vector x
xT = x'
%fprintf	('\nTranspose of vector x: xT = \n');
%disp(xT);