% (c)2021 Hien PHAN.
%Use the function symsum to calculate

clc;
clear;

syms n; 

F = symsum (1/n^2, n, 1, Inf)