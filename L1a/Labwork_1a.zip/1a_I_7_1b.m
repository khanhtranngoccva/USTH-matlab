% (c)2021 Hien PHAN.
clc;
clear;
clf;
    
fplot(@(x) x+1, [-5 5], 'r-+');
grid on