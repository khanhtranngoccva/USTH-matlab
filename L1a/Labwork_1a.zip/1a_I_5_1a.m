% (c)2021 Hien PHAN.
% For loop
clc;
clear;

a = 0;
for i=1:1000
    %disp(i)
    a += i^2;
    % a = a + i^2
end

a