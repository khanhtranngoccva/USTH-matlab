% (c)2021 Hien PHAN.
% Define matrix A by two approaches
clc;
clear;

% Method 1: Define element by element
A1 = [0 0 0;0 0 0;0 0 0]
% Showing the result
%fprintf('\nA1 = \n');
%disp(A1);

% Method 2: the function zeros
A2 = zeros(3:3)
% Showing the result
%fprintf('\nA2 = \n');
%disp(A2);