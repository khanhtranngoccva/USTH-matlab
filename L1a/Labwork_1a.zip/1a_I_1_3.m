% (c)2021 Hien PHAN.
clc;
clear;

%Calculate: a = 1 + 2+ ... + 100 using the function "sum"

a = sum(1:100)
