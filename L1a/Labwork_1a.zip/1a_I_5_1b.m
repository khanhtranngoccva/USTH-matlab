% (c)2021 Hien PHAN.
% For loop
clc;
clear;

b = 1;
for i=1:20
    disp(i)
    b *= i
    % b = b*i
end

%b