% (c)2021 Hien PHAN.
clc;
clear;

%Define a row vector x
x=[1 2 3 4 5]
%fprintf	('Row vector x = \n');
%disp(x);

%find the value x(3)+x(2)
x32 = x(3)+x(2)
%fprintf	('\nx32 = x(3)+x(2) = ');
%disp(x32);